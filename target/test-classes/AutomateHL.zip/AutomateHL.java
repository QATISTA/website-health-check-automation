import io.github.bonigarcia.wdm.WebDriverManager;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.IOException;
import org.apache.commons.io.FileUtils;

public class AutomateHL {
    public static void main(String[] args) throws Exception {
        WebDriverManager.chromedriver().setup();

        // ------------------- CLEANUP OLD DATA -------------------
        String screenshotFolder = "G:\\My Drive\\Automate_SS";
        String urlLogPath = "G:/My Drive/Automation/urls.txt";

        File folder = new File(screenshotFolder);
        if (folder.exists()) {
            FileUtils.cleanDirectory(folder);
        } else {
            folder.mkdirs();
        }

        Path path = Paths.get(urlLogPath);
        if (Files.exists(path)) {
            Files.write(path, new byte[0]);
        } else {
            Files.createDirectories(path.getParent());
            Files.createFile(path);
        }
        // ---------------------------------------------------------

        // ---------- Headless Chrome Setup ----------
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new");
        options.addArguments("--window-size=1920,1080");
        options.addArguments("--disable-gpu");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-blink-features=AutomationControlled");

        // 👇 Fake normal user-agent
        options.addArguments("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/139.0.0.0 Safari/537.36");
        WebDriver driver = new ChromeDriver(options);
        try {
            String testUrl = "https://buy.evergreenevolutions.com/ts-nb-1/int";

            // ================== HTTP2 Status ==================
            driver.get("https://tools.keycdn.com/http2-test");
            driver.findElement(By.id("url")).sendKeys(testUrl);
            driver.findElement(By.id("http2Btn")).click();
            Thread.sleep(2000);
            ((JavascriptExecutor) driver).executeScript("document.body.style.zoom='80%'");
            Thread.sleep(2000);
            saveResult(driver, screenshotFolder, path, "01_http2.png", "1. HTTP2 Report Link");

            // ================== HTTPS Redirection ==================
            driver.navigate().to("https://wheregoes.com/");
            String testUrl_http = testUrl.replaceFirst("^https", "http"); 
            driver.findElement(By.id("url")).sendKeys(testUrl_http);
            driver.findElement(By.id("form_button")).click();
            new WebDriverWait(driver, Duration.ofSeconds(20)).until(
                ExpectedConditions.visibilityOfElementLocated(By.cssSelector("p.date i"))
            );
            ((JavascriptExecutor) driver).executeScript("document.body.style.zoom='55%'");
            Thread.sleep(1000);
            saveResult(driver, screenshotFolder, path, "02_https_redirection.png", "2. HTTPS Redirection Report Link");

            // ================== WhatsMyDNS ==================
            driver.get("https://www.whatsmydns.net/");
            driver.findElement(By.id("q")).sendKeys(testUrl);
            driver.findElement(By.xpath("(//span[@class='ml-2'])[1]")).click();
            new WebDriverWait(driver, Duration.ofSeconds(20)).until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[@class='ml-2'])[1]"))
            );
            Thread.sleep(6500);
            ((JavascriptExecutor) driver).executeScript("document.body.style.zoom='85%'");
            Thread.sleep(1000);
            saveResult(driver, screenshotFolder, path, "03_whatsmydns.png", "3.Domain Test URL Report Link");

            // ================== Safe Browsing ==================
            driver.get("https://transparencyreport.google.com/safe-browsing/search?hl=en");
            Thread.sleep(3500);
            driver.findElement(By.xpath("//input[@placeholder='Search by URL']")).sendKeys(testUrl);
            driver.findElement(By.xpath("//i[normalize-space()='search']")).click();
            Thread.sleep(5000);
            ((JavascriptExecutor) driver).executeScript("document.body.style.zoom='85%'");
            Thread.sleep(1000);
            saveResult(driver, screenshotFolder, path, "04_safe_browsing.png", "4. Safe Browsing Site Status Report Link");

            // ================== Robots.txt ==================
            String withoutProtocol = testUrl.replaceFirst("https?://", "");
            String host = withoutProtocol.split("/")[0];
            String domain = host.replaceAll("^(?:.*\\.)?([^.]+\\.com)$", "$1");

            String testUrl1 = "https://" + domain + "/robots.txt";
            try {
                driver.get(testUrl1);
            } catch (WebDriverException e) {
                System.out.println("Direct domain failed, retrying with www...");
                testUrl1 = "https://www." + domain + "/robots.txt";
                driver.get(testUrl1);
            }

            Thread.sleep(2000);
            saveResult(driver, screenshotFolder, path, "05_robots.png", "5. Robots.txt Report Link");

            // ================== Domain Expiry ==================
         // ================== Domain Expiry ==================
            String testUrl2 =  domain;
            driver.get("https://www.digicert.com/help/");
            driver.findElement(By.id("host")).sendKeys(testUrl2);
            driver.findElement(By.id("check-server-button")).click();
            Thread.sleep(12000);
          //  ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 500);");
          //  ((JavascriptExecutor) driver).executeScript("document.body.style.zoom='80%'");
            //===== Pr code start ================
            WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(100));
			WebElement element = wait1.until(
			        ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[normalize-space()='TLS Certificate has not been revoked']"))
			);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			//===== Pr code end ================
            Thread.sleep(1000);
            saveResult(driver, screenshotFolder, path, "06_domain_expiry.png", "6. Domain Expiry check Report Link");
         // SSL Grade
            driver.get("https://www.ssllabs.com/ssltest");
            driver.findElement(By.xpath("//input[@name='d']")).sendKeys(testUrl);
            driver.findElement(By.xpath("//input[@value='Submit']")).click();
            // new WebDriverWait(driver, Duration.ofSeconds(30))
            // .until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='multiTable']")));
            new WebDriverWait(driver, Duration.ofSeconds(10000)) 
              .until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("a[href='index.html']")));
            ((JavascriptExecutor) driver).executeScript("document.body.style.zoom='60%'");
            Thread.sleep(1000);
            saveResult(driver, screenshotFolder, path, "07_ssllabs.png", "7. SSL Grade Report Link");
        


            // ================== PageSpeed Insights ==================
            driver.get("https://pagespeed.web.dev/?utm_source=psi&utm_medium=redirect");
            driver.findElement(By.xpath("//input[@id='i2']")).sendKeys(testUrl);
            driver.findElement(By.xpath("//span[normalize-space()='Analyze']")).click();

            // Mobile tab
            new WebDriverWait(driver, Duration.ofSeconds(180)).until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@id='performance'])[1]"))
            );
            driver.findElement(By.id("mobile_tab")).click();
            Thread.sleep(1000);
            WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(100));
            WebElement element3 = wait3.until(
                ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//*[contains(normalize-space(text()),'Diagnose performance')]")
                )
            );
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", element3);
            Thread.sleep(1000);
            ((JavascriptExecutor) driver).executeScript("document.body.style.zoom='75%'");
            saveResult(driver, screenshotFolder, path, "08_pagespeed_mobile.png", "8. Google PageSpeed Mobile Report Link");

            // Desktop tab
            driver.findElement(By.id("desktop_tab")).click();
            new WebDriverWait(driver, Duration.ofSeconds(180)).until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@id='screenshot-thumbnails'])[2]"))
            );
            Thread.sleep(1000);
            WebDriverWait wait4 = new WebDriverWait(driver, Duration.ofSeconds(100));
            WebElement element4 = wait4.until(
                ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//*[contains(normalize-space(text()),'Diagnose performance')]")
                )
            );
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", element4);
            Thread.sleep(1000);
            ((JavascriptExecutor) driver).executeScript("document.body.style.zoom='75%'");
            saveResult(driver, screenshotFolder, path, "09_pagespeed_desktop.png", "9. Google PageSpeed Desktop Report Link");

        } finally {
            driver.quit();
        }
    }

    // ------------------- Helper Method -------------------
    private static void saveResult(WebDriver driver, String folder, Path path,
                                   String fileName, String label) throws IOException {
        File ss = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(ss, new File(folder + "\\" + fileName));

        String currentUrl = driver.getCurrentUrl();
        Files.write(
            path,
            (label + ": " + currentUrl + "\n").getBytes(),
            StandardOpenOption.APPEND
        );
        System.out.println(label + ": " + currentUrl);
    }
}
